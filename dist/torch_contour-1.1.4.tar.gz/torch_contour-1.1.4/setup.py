import setuptools  # type: ignore

setuptools.setup()